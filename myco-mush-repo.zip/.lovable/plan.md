## Goal
Recreate `myco-mush-nine.vercel.app` (Myco Wonderland — functional mushroom + herbal healing brand) inside this Lovable project, preserving the original information architecture and tone while leveling up the visuals, motion, and mobile responsiveness. Visual direction blends the user's uploaded sun-eye art with the neon/cyber editorial language of amstudio.digital.

## Visual direction

- **Palette (mystical neon on near-black):** background `#0a0612`, surface `#120a1f`, ink `#f5f0ff`, primary magenta `#e94aa8`, accent violet `#7c3aed`, accent cyan `#2dd4bf` (echoing the uploaded cyan grid art), warm amber `#ff8a3d` for grid gradient.
- **Type:** `Syne` (700/800) for display headlines, `Space Mono` for labels/tags (`> section // 01` style from amstudios), `Inter` for body. Loaded via `<link>` in `__root.tsx` head; mapped through `@theme` tokens in `src/styles.css`.
- **Tokens in `src/styles.css`:** oklch values for every color, gradient tokens (`--gradient-grid: linear-gradient(180deg, violet, magenta, amber)`, `--gradient-aura`), glow shadow tokens, and a noise/grain utility.
- **Motion:** subtle parallax, scroll-reveal, hover glow on cards, sun-eye breathes (scale sine) and slowly rotates; respects `prefers-reduced-motion`.

## Hero — Three.js sun-eye + neon grid

- `src/components/HeroScene.tsx` mounts a Three.js scene (install `three`, `@types/three`) with:
  - A wireframe `PlaneGeometry` (subdivided) using a `ShaderMaterial` that drives line color along Y from amber → magenta → violet and animates vertices with layered sine waves (the synthwave grid from the reference).
  - The uploaded sun-eye PNG loaded as a `MeshBasicMaterial` texture on a `PlaneGeometry`, centered above the grid horizon, breathing with `sin(t)` scale and gentle z-rotation.
  - Soft additive bloom feel via a radial gradient div underneath for performance (no postprocessing pass — keeps mobile fast).
  - DPR clamped to `min(devicePixelRatio, 2)`, scene paused with `IntersectionObserver`, reduced-motion fallback renders a static gradient + sun-eye image.
- Hero text overlays the canvas: small mono eyebrow `> myco wonderland // healing`, Syne display headline, supporting copy, dual CTAs (filled cyan + outlined magenta, echoing amstudios buttons).

## Information architecture (single-page, route `/`)

Mirrors the original site, expressed as section components under `src/components/sections/`:

1. `Nav` — sticky, translucent, mono links, glow on hover.
2. `Hero` — Three.js scene above.
3. `Trust` — marquee of "lab-tested · organic · vegan · third-party verified" badges.
4. `Products` / `Featured Blends` — 3-card grid (Lion's Mane, Reishi, Cordyceps, etc. — pulled from the live site's copy) with cyan-grid art as card background accent.
5. `Benefits` — 4 icon tiles (focus, calm, immunity, energy) with subtle aura gradient.
6. `Ritual / Process` — 3-step zigzag using the `> 01` mono numerals from amstudios.
7. `Story / About` — split: copy left, embedded cyan-grid art right inside a glowing frame.
8. `Testimonials` — minimal quote cards.
9. `FAQ` — accordion (shadcn).
10. `Contact / Newsletter` — terminal-style form (`> email:`, `Send Transmission`) matching amstudios feel.
11. `Footer` — minimal, mono.

Each section gets semantic HTML, single H1 in Hero, proper alt text on the sun-eye and cyan-grid art.

## Assets

- Upload the two user images via `lovable-assets` from `/mnt/user-uploads/` into `src/assets/*.asset.json` (sun-eye for hero texture; cyan-grid for About frame + card backgrounds). No binaries committed.

## Performance & responsiveness

- Three.js scene lazy-mounted with `React.lazy` + `Suspense` fallback (static hero image) so initial paint isn't blocked.
- All sections built mobile-first: fluid type via `clamp()`, grid → stack at `md`, touch-friendly tap targets, hero canvas height capped on mobile, reduced grid subdivisions on small screens.
- Image `loading="lazy"` below the fold, `decoding="async"`.
- SEO head in `routes/index.tsx`: title, meta description, OG/Twitter tags using sun-eye as `og:image`.

## Technical notes

- Stack stays TanStack Start (no new framework). Replace `src/routes/index.tsx` placeholder with the new home page; add section components under `src/components/sections/` and the Three.js scene under `src/components/HeroScene.tsx`.
- Install: `bun add three @types/three`.
- Fonts loaded via `<link>` in `src/routes/__root.tsx` head (per Tailwind v4 rule — no remote `@import` in CSS).
- All colors live in `src/styles.css` as oklch tokens and are referenced via Tailwind classes (`bg-background`, `text-primary`, etc.) — no hardcoded hex in components.
- Reduced-motion: media query disables Three.js animation loop and shader time uniform.

## Out of scope (ask before adding)
- E-commerce checkout, real product database, auth, CMS — current site is marketing only; this rebuild stays marketing-only unless you want backend wired up.
